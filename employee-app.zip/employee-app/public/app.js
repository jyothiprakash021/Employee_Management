const API = '/api/employees';
let employees = [];
let editId = null;
const fields = ['name', 'email', 'department', 'position', 'salary'];

async function loadEmployees() {
  const res = await fetch(API);
  employees = await res.json();
  render(employees);
}

function render(list) {
  document.getElementById('tableBody').innerHTML = list.map(e => `
    <tr>
      <td>${e.name}</td><td>${e.email}</td><td>${e.department}</td><td>${e.position}</td>
      <td>₹${e.salary.toLocaleString()}</td>
      <td>
        <button class="edit" onclick="editEmployee('${e._id}')">Edit</button>
        <button class="delete" onclick="deleteEmployee('${e._id}')">Delete</button>
      </td>
    </tr>`).join('');
}

document.getElementById('saveBtn').addEventListener('click', async () => {
  const data = {};
  fields.forEach(f => data[f] = document.getElementById(f).value);
  const url = editId ? `${API}/${editId}` : API;
  const res = await fetch(url, {
    method: editId ? 'PUT' : 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
  if (!res.ok) { const err = await res.json(); return alert(err.message); }
  fields.forEach(f => document.getElementById(f).value = '');
  editId = null;
  document.getElementById('formTitle').innerText = 'Add Employee';
  loadEmployees();
});

function editEmployee(id) {
  const e = employees.find(x => x._id === id);
  fields.forEach(f => document.getElementById(f).value = e[f]);
  editId = id;
  document.getElementById('formTitle').innerText = 'Edit Employee';
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

async function deleteEmployee(id) {
  if (!confirm('Delete this employee?')) return;
  await fetch(`${API}/${id}`, { method: 'DELETE' });
  loadEmployees();
}

document.getElementById('search').addEventListener('input', (e) => {
  const q = e.target.value.toLowerCase();
  render(employees.filter(emp =>
    emp.name.toLowerCase().includes(q) || emp.department.toLowerCase().includes(q)));
});

loadEmployees();
